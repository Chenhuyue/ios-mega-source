// Muse 宠物 · 组件内互动意图（点按钮时执行，不打开 App）
import { AppIntentManager, AppIntentProtocol, Widget } from "scripting"
import { doFeed, doPet, doPlay } from "./model"

export const PetHeadIntent = AppIntentManager.register({
  name: "PetHead",
  protocol: AppIntentProtocol.AppIntent,
  perform: async () => {
    doPet()
    Widget.reloadAll()
  },
})

export const FeedIntent = AppIntentManager.register({
  name: "PetFeed",
  protocol: AppIntentProtocol.AppIntent,
  perform: async () => {
    doFeed()
    Widget.reloadAll()
  },
})

export const PlayIntent = AppIntentManager.register({
  name: "PetPlay",
  protocol: AppIntentProtocol.AppIntent,
  perform: async () => {
    doPlay()
    Widget.reloadAll()
  },
})
