// Muse 宠物 · 数据层 v2（widget.tsx / app_intents.tsx / index.tsx 共用）
// 星核形象：四维数值与宠物房同名（星光/能量/星尘/通讯），衰减沿用 v1 节奏——
// 星尘（原饱腹）掉得最快、夜间能量掉得快、通讯慢掉、星光被星尘与能量拖着走。
// 数值存本机 Storage；形象图（黑曜石纹理 + 走廊舱背景）运行时拉取并缓存到
// App Group 目录（FileManager.documentsDirectory 组件读不到，官方文档明示），
// 拉不到就用旧缓存，再没有就由 widget 侧回退绘制，永不空白。

export type Emotion =
  | "normal"
  | "happy"
  | "proud"
  | "sleepy"
  | "sleep"
  | "disdain"
  | "angry"

export type PetState = {
  starlight: number // 星光 0-100（心情）
  energy: number // 能量 0-100（精力）
  stardust: number // 星尘 0-100（库存，越高越满）
  link: number // 通讯 0-100（亲近度）
  exp: number
  adoptedAt: number // 通讯建立时间戳
  lastTick: number // 上次结算衰减的时间戳
  override: Emotion | null // 互动后的短时情绪
  overrideUntil: number
}

const STATE_KEY = "pet.state.v2"

export const PET_ROOM_URL = "hatch://space/muse-chong-wu-fang"
export const PET_NAME = "煤球"
export const WIDGET_VERSION = "v2.0.0"

// ---------- 形象图资源（仓库托管，jsdelivr 主链） ----------

const REPO = "Chenhuyue/ios-mega-source@main"
export const TEX_URLS = [
  `https://cdn.jsdelivr.net/gh/${REPO}/pet/tex-obsidian.webp`,
  `https://fastly.jsdelivr.net/gh/${REPO}/pet/tex-obsidian.webp`,
  `https://raw.githubusercontent.com/Chenhuyue/ios-mega-source/main/pet/tex-obsidian.webp`,
]
export const CABIN_URLS = [
  `https://cdn.jsdelivr.net/gh/${REPO}/pet/cabin-bg-b.webp`,
  `https://fastly.jsdelivr.net/gh/${REPO}/pet/cabin-bg-b.webp`,
  `https://raw.githubusercontent.com/Chenhuyue/ios-mega-source/main/pet/cabin-bg-b.webp`,
]

export type PetAssets = {
  /** 黑曜石纹理的本地缓存路径；从未拉到过为 null */
  sphere: string | null
  /** 走廊舱背景的本地缓存路径；从未拉到过为 null */
  cabin: string | null
}

const ASSET_DIR = () => FileManager.appGroupDocumentsDirectory + "/muse-pet-assets"
const ASSET_TS_KEY = "pet.assets.ts.v2"
const ASSET_MAX_AGE = 24 * 3600 * 1000

function safeExists(path: string): boolean {
  try {
    return FileManager.existsSync(path)
  } catch {
    return false
  }
}

function withTimeout<T>(work: Promise<T>, ms: number): Promise<T | null> {
  return Promise.race([
    work.catch(() => null),
    new Promise<null>((resolve) => setTimeout(() => resolve(null), ms)),
  ]) as Promise<T | null>
}

/** 依次试各镜像链，整图先下进内存再一次写盘，避免半截文件。 */
async function fetchToFile(urls: string[], filePath: string): Promise<boolean> {
  for (const url of urls) {
    const ok = await withTimeout(
      (async () => {
        const res = await fetch(url)
        if (!res.ok) return false
        const buf = await res.arrayBuffer()
        if (!buf || buf.byteLength < 1024) return false
        FileManager.writeAsBytesSync(filePath, new Uint8Array(buf))
        return true
      })(),
      8000
    )
    if (ok) return true
  }
  return false
}

/**
 * 确保形象图在本地缓存里：有缓存且未过期（24h）直接用；
 * 缺失或过期才联网拉，拉失败保留旧缓存。返回可用路径（可能为 null）。
 */
export async function ensureAssets(): Promise<PetAssets> {
  const dir = ASSET_DIR()
  try {
    if (!FileManager.existsSync(dir)) FileManager.createDirectorySync(dir, true)
  } catch {}
  const spherePath = dir + "/tex-obsidian.webp"
  const cabinPath = dir + "/cabin-bg-b.webp"
  const last = Storage.get<number>(ASSET_TS_KEY)
  const stale = !last || Date.now() - last > ASSET_MAX_AGE
  let refreshed = false
  if (!safeExists(spherePath) || stale) {
    if (await fetchToFile(TEX_URLS, spherePath)) refreshed = true
  }
  if (!safeExists(cabinPath) || stale) {
    if (await fetchToFile(CABIN_URLS, cabinPath)) refreshed = true
  }
  if (refreshed) Storage.set(ASSET_TS_KEY, Date.now())
  return {
    sphere: safeExists(spherePath) ? spherePath : null,
    cabin: safeExists(cabinPath) ? cabinPath : null,
  }
}

// ---------- 数值与情绪 ----------

function clamp(n: number): number {
  return Math.max(0, Math.min(100, Math.round(n)))
}

function defaultState(now: number): PetState {
  return {
    starlight: 72,
    energy: 80,
    stardust: 65,
    link: 30,
    exp: 0,
    adoptedAt: now,
    lastTick: now,
    override: null,
    overrideUntil: 0,
  }
}

/** 读状态并按流逝时间结算衰减。 */
export function loadState(): PetState {
  const now = Date.now()
  const saved = Storage.get<PetState>(STATE_KEY)
  if (!saved || typeof saved.starlight !== "number") {
    const s = defaultState(now)
    Storage.set(STATE_KEY, s)
    return s
  }
  const s: PetState = { ...defaultState(now), ...saved }
  const hours = Math.max(0, (now - s.lastTick) / 3600000)
  if (hours > 0.05) {
    const hour = new Date(now).getHours()
    const night = hour >= 23 || hour < 7
    s.stardust = clamp(s.stardust - hours * 6)
    s.energy = clamp(s.energy - hours * (night ? 7 : 3.5))
    s.link = clamp(s.link - hours * 0.8)
    // 星光被星尘和能量拖着走
    const drag = (s.stardust < 30 ? 10 : 0) + (s.energy < 25 ? 8 : 0)
    s.starlight = clamp(s.starlight + (55 - drag - s.starlight) * Math.min(1, hours * 0.25))
    s.lastTick = now
    Storage.set(STATE_KEY, s)
  }
  return s
}

export function saveState(s: PetState) {
  Storage.set(STATE_KEY, s)
}

export function levelOf(exp: number): number {
  return Math.floor(exp / 30) + 1
}

export function companionDays(s: PetState): number {
  return Math.floor((Date.now() - s.adoptedAt) / 86400000) + 1
}

/** 当前情绪：短时互动情绪优先，其余按数值 + 时段判定。 */
export function emotionOf(s: PetState): Emotion {
  const now = Date.now()
  if (s.override && s.overrideUntil > now) return s.override
  const hour = new Date(now).getHours()
  if ((hour >= 23 || hour < 6) && s.energy < 70) return "sleep"
  if (s.energy <= 12) return "sleep"
  if (s.energy <= 30) return "sleepy"
  if (s.stardust <= 25) return "disdain"
  if (s.link <= 18 && s.starlight < 62) return "disdain"
  if (s.starlight <= 30) return "sleepy"
  if (s.starlight >= 78) return "happy"
  if (s.starlight >= 62 && s.energy >= 70) return "proud"
  return "normal"
}

export const EMOTION_LABEL: Record<Emotion, string> = {
  normal: "平常",
  happy: "开心",
  proud: "得意",
  sleepy: "犯困",
  sleep: "休眠",
  disdain: "嫌弃",
  angry: "生气",
}

/** 每种情绪一句煤球台词（嘴硬心软、四川味，不堆梗）。 */
export const EMOTION_LINE: Record<Emotion, string> = {
  normal: "在的，地面站，有事说话",
  happy: "今天信号巴适得很",
  proud: "看到没，核心又进化了",
  sleepy: "能量有点低，我眯一会儿",
  sleep: "休眠中……天亮再喊我",
  disdain: "哼，星尘见底了才想起我",
  angry: "点点点，点轻点嘛！",
}

function withOverride(s: PetState, e: Emotion, minutes: number): PetState {
  return { ...s, override: e, overrideUntil: Date.now() + minutes * 60000 }
}

/** 摸头：星光+6、通讯+4、经验+2，短时变开心（连点太快会生气）。 */
export function doPet(): PetState {
  const s = loadState()
  const now = Date.now()
  if (s.override === "happy" && s.overrideUntil - now > 25 * 60000) {
    // 30 分钟内反复猛点：惹毛了
    const angry = withOverride({ ...s, starlight: clamp(s.starlight - 5) }, "angry", 10)
    saveState(angry)
    return angry
  }
  const next = withOverride(
    {
      ...s,
      starlight: clamp(s.starlight + 6),
      link: clamp(s.link + 4),
      exp: s.exp + 2,
    },
    "happy",
    30
  )
  saveState(next)
  return next
}

/** 投喂星尘：星尘+25、星光+4、经验+2，短时开心眯眼。 */
export function doFeed(): PetState {
  const s = loadState()
  const next = withOverride(
    {
      ...s,
      stardust: clamp(s.stardust + 25),
      starlight: clamp(s.starlight + 4),
      exp: s.exp + 2,
    },
    "happy",
    20
  )
  saveState(next)
  return next
}

/** 逗玩：星光+8、通讯+2、经验+3、能量-5，短时得意（带淡环）。 */
export function doPlay(): PetState {
  const s = loadState()
  const next = withOverride(
    {
      ...s,
      starlight: clamp(s.starlight + 8),
      link: clamp(s.link + 2),
      energy: clamp(s.energy - 5),
      exp: s.exp + 3,
    },
    "proud",
    20
  )
  saveState(next)
  return next
}

export function resetPet() {
  Storage.set(STATE_KEY, defaultState(Date.now()))
}
