// Muse 宠物 · 桌面小组件 v2（Scripting）
// 星核形象与宠物房定版对齐：球身＝乙黑曜石纹理原图（正面中心裁圆）、眼睛＝代码胶囊
// （高:宽 = 2.2:1，靠眼形换表情），背景＝乙走廊舱图 cover 垫底。
// 形象图运行时拉取并缓存到 App Group 目录；拉不到用旧缓存，再没有回退代码绘制，不空白。
// 互动全走 AppIntent（组件内执行、不打开 App）：点球身＝摸头，两钮＝投喂星尘/逗玩；
// 跳宠物房的 Link 只占右上角小片，与按钮做兄弟节点、不嵌套（照启动器已验写法）。
import {
  Button,
  Capsule,
  Circle,
  HStack,
  Image,
  Link,
  Rectangle,
  RoundedRectangle,
  Spacer,
  Text,
  VStack,
  Widget,
  ZStack,
} from "scripting"
import { FeedIntent, PetHeadIntent, PlayIntent } from "./app_intents"
import {
  EMOTION_LABEL,
  EMOTION_LINE,
  Emotion,
  PET_NAME,
  PET_ROOM_URL,
  PetAssets,
  PetState,
  WIDGET_VERSION,
  companionDays,
  emotionOf,
  ensureAssets,
  levelOf,
  loadState,
} from "./model"

const SUB = "#9AA3B2"
const INK = "#F4F6FF"
const REFRESH_MINUTES = 30

// 舱图原始尺寸 1152×2048；纹理 2240×1120（2:1）
const CABIN_W = 1152
const CABIN_H = 2048

/** 背景：舱图 cover 垫底（放大盖满、焦点落在图高 62% 处，舷窗与停机坪同框）；无缓存时深色渐变回退。 */
function CabinBackground(w: number, h: number, assets: PetAssets) {
  const scale = Math.max(w / CABIN_W, h / CABIN_H) * 1.12
  const iw = Math.round(CABIN_W * scale)
  const ih = Math.round(CABIN_H * scale)
  const oy = -Math.round(0.12 * ih)
  return (
    <ZStack frame={{ width: w, height: h }}>
      <Rectangle fill="#0B1220" frame={{ width: w, height: h }} />
      {assets.cabin ? (
        <Image
          filePath={assets.cabin}
          resizable={{ resizingMode: "stretch" }}
          frame={{ width: iw, height: ih }}
          width={iw}
          height={ih}
          offset={{ x: 0, y: oy }}
        />
      ) : null}
      <Rectangle fill="rgba(3,5,10,0.30)" frame={{ width: w, height: h }} />
    </ZStack>
  )
}

/** 纹理缺失时的回退球：深色圆 + 代码走线纹（形状都套在定尺寸 ZStack 里，照已验写法）。 */
function CodeBall(D: number) {
  return (
    <ZStack frame={{ width: D, height: D }}>
      <Circle fill="#14161D" />
      <Capsule
        fill="rgba(94,200,220,0.30)"
        frame={{ width: Math.round(D * 0.62), height: 2 }}
        rotationEffect={24}
      />
      <Capsule
        fill="rgba(94,200,220,0.22)"
        frame={{ width: Math.round(D * 0.5), height: 2 }}
        rotationEffect={-32}
        offset={{ x: 0, y: Math.round(D * 0.16) }}
      />
      <Capsule
        fill="rgba(150,130,255,0.20)"
        frame={{ width: Math.round(D * 0.44), height: 2 }}
        rotationEffect={66}
        offset={{ x: Math.round(D * 0.08), y: -Math.round(D * 0.18) }}
      />
      <ZStack frame={{ width: 4, height: 4 }} offset={{ x: -Math.round(D * 0.2), y: -Math.round(D * 0.1) }}>
        <Circle fill="rgba(120,220,255,0.55)" />
      </ZStack>
      <ZStack frame={{ width: 3, height: 3 }} offset={{ x: Math.round(D * 0.22), y: Math.round(D * 0.14) }}>
        <Circle fill="rgba(120,220,255,0.45)" />
      </ZStack>
    </ZStack>
  )
}

/** 球身：纹理图以 2 倍宽显示在圆裁切里，正面中心区域正好填满圆（等距纹理的正面）。 */
function SphereBody(D: number, assets: PetAssets) {
  return (
    <ZStack frame={{ width: D, height: D }} clipShape="circle">
      {assets.sphere ? (
        <Image
          filePath={assets.sphere}
          resizable={{ resizingMode: "stretch" }}
          frame={{ width: 2 * D, height: D }}
          width={2 * D}
          height={D}
        />
      ) : (
        CodeBall(D)
      )}
    </ZStack>
  )
}

/** 眼睛：瓷白胶囊，高:宽 = 2.2:1（与宠物房定版一致），靠眼高与倾斜换表情。 */
function Eyes(e: Emotion, D: number) {
  const ew = Math.max(4, Math.round(D * 0.105))
  const eh = Math.round(D * 0.23)
  let w = ew
  let h = eh
  let rotL = 0
  let rotR = 0
  switch (e) {
    case "happy": // 开心眯眼：压扁
      h = Math.max(3, Math.round(eh * 0.26))
      w = Math.round(ew * 1.2)
      break
    case "proud": // 得意：半眯
      h = Math.round(eh * 0.5)
      break
    case "sleepy": // 困：半闭
      h = Math.round(eh * 0.42)
      break
    case "sleep": // 睡：闭眼细线
      h = 3
      w = Math.round(ew * 1.15)
      break
    case "disdain": // 嫌弃：双眼同向斜
      h = Math.round(eh * 0.8)
      rotL = -14
      rotR = -14
      break
    case "angry": // 生气：向内斜切
      h = Math.round(eh * 0.85)
      rotL = 18
      rotR = -18
      break
    default:
      break
  }
  return (
    <HStack spacing={Math.round(D * 0.105)} offset={{ x: 0, y: -Math.round(D * 0.05) }}>
      <Capsule fill={INK} frame={{ width: w, height: h }} rotationEffect={rotL} />
      <Capsule fill={INK} frame={{ width: w, height: h }} rotationEffect={rotR} />
    </HStack>
  )
}

/** 脸：得意时球外多一圈淡环；边缘一圈极淡描边把球从背景里托出来。 */
function Face(e: Emotion, D: number, assets: PetAssets) {
  return (
    <ZStack frame={{ width: D + 12, height: D + 12 }}>
      {e === "proud" ? (
        <ZStack frame={{ width: D + 8, height: D + 8 }}>
          <Circle
            fill="rgba(0,0,0,0)"
            stroke={{ shapeStyle: "rgba(140,210,255,0.45)", strokeStyle: { lineWidth: 2 } }}
          />
        </ZStack>
      ) : null}
      {SphereBody(D, assets)}
      <ZStack frame={{ width: D, height: D }}>
        <Circle
          fill="rgba(0,0,0,0)"
          stroke={{ shapeStyle: "rgba(170,205,255,0.20)", strokeStyle: { lineWidth: 1 } }}
        />
      </ZStack>
      {Eyes(e, D)}
    </ZStack>
  )
}

/** 点球身＝摸头（组件内意图，不打开 App）。 */
function FaceButton(e: Emotion, D: number, assets: PetAssets) {
  return (
    <Button intent={PetHeadIntent(undefined)} buttonStyle="plain">
      {Face(e, D, assets)}
    </Button>
  )
}

function RoomLinkChip(w: number, h: number, font: number) {
  return (
    <Link url={PET_ROOM_URL}>
      <ZStack frame={{ width: w, height: h }}>
        <RoundedRectangle cornerRadius={999} fill="rgba(10,14,24,0.55)" />
        <Text font={font} foregroundStyle="#C9D2E8">
          宠物房 ›
        </Text>
      </ZStack>
    </Link>
  )
}

function LevelChip(s: PetState, w: number, h: number, font: number) {
  return (
    <ZStack frame={{ width: w, height: h }}>
      <RoundedRectangle cornerRadius={999} fill="rgba(255,209,102,0.20)" />
      <Text font={font} foregroundStyle="#FFD166">
        {`Lv.${levelOf(s.exp)}`}
      </Text>
    </ZStack>
  )
}

function Bar(label: string, value: number, color: string, trackW: number) {
  const fillW = Math.max(3, Math.round((trackW * value) / 100))
  return (
    <HStack spacing={6}>
      <Text font={10} foregroundStyle={SUB}>
        {label}
      </Text>
      <ZStack frame={{ width: trackW, height: 6 }}>
        <RoundedRectangle cornerRadius={3} fill="rgba(255,255,255,0.16)" />
        <HStack>
          <RoundedRectangle cornerRadius={3} fill={color} frame={{ width: fillW, height: 6 }} />
          <Spacer />
        </HStack>
      </ZStack>
      <Text font={10} foregroundStyle={SUB}>
        {`${value}`}
      </Text>
    </HStack>
  )
}

function ActionButtons(btnW: number) {
  return (
    <HStack spacing={8}>
      <Button intent={FeedIntent(undefined)} buttonStyle="plain">
        <ZStack frame={{ width: btnW, height: 24 }}>
          <RoundedRectangle cornerRadius={999} fill="#F4F6FF" />
          <Text font={11} fontWeight="semibold" foregroundStyle="#101218">
            投喂星尘
          </Text>
        </ZStack>
      </Button>
      <Button intent={PlayIntent(undefined)} buttonStyle="plain">
        <ZStack frame={{ width: btnW, height: 24 }}>
          <RoundedRectangle cornerRadius={999} fill="rgba(10,14,24,0.55)" />
          <Text font={11} foregroundStyle="#E8EDFF">
            逗玩
          </Text>
        </ZStack>
      </Button>
      <Spacer />
    </HStack>
  )
}

function VersionMark() {
  return (
    <VStack frame={{ maxWidth: "infinity", maxHeight: "infinity" }} padding={5}>
      <Spacer />
      <HStack>
        <Spacer />
        <Text font={8} foregroundStyle="rgba(200,212,235,0.5)">
          {WIDGET_VERSION}
        </Text>
      </HStack>
    </VStack>
  )
}

function Shell(w: number, h: number, assets: PetAssets, content: any) {
  return (
    <ZStack frame={{ maxWidth: "infinity", maxHeight: "infinity" }}>
      {CabinBackground(w, h, assets)}
      {content}
      {VersionMark()}
    </ZStack>
  )
}

function MediumView(s: PetState, e: Emotion, assets: PetAssets) {
  const content = (
    <VStack alignment="leading" spacing={6} padding={12}>
      <HStack spacing={6}>
        <Text font={13} fontWeight="bold" foregroundStyle="#F5F7FF">
          {PET_NAME}
        </Text>
        {LevelChip(s, 46, 18, 9)}
        <ZStack frame={{ width: 122, height: 18 }}>
          <RoundedRectangle cornerRadius={999} fill="rgba(5,8,14,0.45)" />
          <Text font={9} foregroundStyle={SUB}>
            {`${EMOTION_LABEL[e]} · 通讯第 ${companionDays(s)} 天`}
          </Text>
        </ZStack>
        <Spacer />
        {RoomLinkChip(62, 20, 9)}
      </HStack>
      <HStack spacing={12}>
        {FaceButton(e, 78, assets)}
        <ZStack
          background={
            <RoundedRectangle cornerRadius={12} fill="rgba(5,8,14,0.45)" />
          }
        >
          <VStack alignment="leading" spacing={5} padding={8}>
            {Bar("星光", s.starlight, "#FFD166", 112)}
            {Bar("能量", s.energy, "#8EC8FF", 112)}
            {Bar("星尘", s.stardust, "#6EE7A0", 112)}
            {Bar("通讯", s.link, "#FF9FB2", 112)}
            <Text font={11} foregroundStyle="#EDF1FF">
              {EMOTION_LINE[e]}
            </Text>
          </VStack>
        </ZStack>
        <Spacer />
      </HStack>
      {ActionButtons(96)}
    </VStack>
  )
  return Shell(364, 170, assets, content)
}

function SmallView(s: PetState, e: Emotion, assets: PetAssets) {
  const content = (
    <VStack alignment="leading" spacing={6} padding={10}>
      <HStack spacing={5}>
        <Text font={12} fontWeight="bold" foregroundStyle="#F5F7FF">
          {PET_NAME}
        </Text>
        {LevelChip(s, 40, 16, 8)}
        <Spacer />
        {RoomLinkChip(50, 16, 8)}
      </HStack>
      <HStack>
        <Spacer />
        {FaceButton(e, 82, assets)}
        <Spacer />
      </HStack>
      <HStack spacing={8}>
        <Spacer />
        <Button intent={FeedIntent(undefined)} buttonStyle="plain">
          <ZStack frame={{ width: 58, height: 22 }}>
            <RoundedRectangle cornerRadius={999} fill="#F4F6FF" />
            <Text font={10} fontWeight="semibold" foregroundStyle="#101218">
              投喂
            </Text>
          </ZStack>
        </Button>
        <Button intent={PlayIntent(undefined)} buttonStyle="plain">
          <ZStack frame={{ width: 58, height: 22 }}>
            <RoundedRectangle cornerRadius={999} fill="rgba(10,14,24,0.55)" />
            <Text font={10} foregroundStyle="#E8EDFF">
              逗玩
            </Text>
          </ZStack>
        </Button>
        <Spacer />
      </HStack>
    </VStack>
  )
  return Shell(170, 170, assets, content)
}

function LargeView(s: PetState, e: Emotion, assets: PetAssets) {
  const content = (
    <VStack alignment="leading" spacing={8} padding={14}>
      <HStack spacing={6}>
        <Text font={15} fontWeight="bold" foregroundStyle="#F5F7FF">
          {PET_NAME}
        </Text>
        {LevelChip(s, 52, 20, 10)}
        <ZStack frame={{ width: 134, height: 20 }}>
          <RoundedRectangle cornerRadius={999} fill="rgba(5,8,14,0.45)" />
          <Text font={10} foregroundStyle={SUB}>
            {`${EMOTION_LABEL[e]} · 通讯第 ${companionDays(s)} 天`}
          </Text>
        </ZStack>
        <Spacer />
        {RoomLinkChip(68, 22, 10)}
      </HStack>
      <HStack>
        <Spacer />
        {FaceButton(e, 144, assets)}
        <Spacer />
      </HStack>
      <Text font={12} foregroundStyle="#EDF1FF">
        {EMOTION_LINE[e]}
      </Text>
      {Bar("星光", s.starlight, "#FFD166", 220)}
      {Bar("能量", s.energy, "#8EC8FF", 220)}
      {Bar("星尘", s.stardust, "#6EE7A0", 220)}
      {Bar("通讯", s.link, "#FF9FB2", 220)}
      <Spacer />
      {ActionButtons(110)}
    </VStack>
  )
  return Shell(364, 382, assets, content)
}

async function main() {
  const reloadPolicy = {
    policy: "after",
    date: new Date(Date.now() + REFRESH_MINUTES * 60 * 1000),
  } as const
  const s = loadState()
  const e = emotionOf(s)
  let assets: PetAssets = { sphere: null, cabin: null }
  try {
    assets = await ensureAssets()
  } catch {}
  try {
    switch (Widget.family) {
      case "systemSmall":
        Widget.present(SmallView(s, e, assets), { reloadPolicy })
        break
      case "systemLarge":
      case "systemExtraLarge":
        Widget.present(LargeView(s, e, assets), { reloadPolicy })
        break
      case "systemMedium":
      default:
        Widget.present(MediumView(s, e, assets), { reloadPolicy })
        break
    }
  } catch {
    Widget.present(
      <VStack padding={12} background="#0A0B0F">
        <Text font={12} foregroundStyle="#F5F7FF">
          {`${PET_NAME} · ${EMOTION_LABEL[e]}`}
        </Text>
      </VStack>,
      { reloadPolicy }
    )
  }
}

main()
