// Muse 宠物 · App 内页面（说明 + 快捷互动；桌面组件本体在 widget.tsx）
// 打开本页会顺手把形象图缓存热好，组件首次上桌就不用等下载。
import {
  Button,
  HStack,
  Link,
  Navigation,
  Script,
  Spacer,
  Text,
  VStack,
  Widget,
} from "scripting"
import {
  EMOTION_LABEL,
  PET_ROOM_URL,
  WIDGET_VERSION,
  doFeed,
  doPet,
  doPlay,
  emotionOf,
  ensureAssets,
  loadState,
  resetPet,
} from "./model"

function App() {
  const s = loadState()
  const e = emotionOf(s)
  return (
    <VStack alignment="leading" spacing={14} padding={18}>
      <Text font={20} fontWeight="bold">
        Muse 宠物 · 煤球（星核）
      </Text>
      <Text font={13} foregroundStyle="#9AA3B2">
        {`现在是「${EMOTION_LABEL[e]}」：星光 ${s.starlight} · 能量 ${s.energy} · 星尘 ${s.stardust} · 通讯 ${s.link}。桌面组件会按这四维数值自己换脸；点组件右上角进宠物房，那里有真动画。`}
      </Text>
      <Link url={PET_ROOM_URL}>
        <Text font={14} foregroundStyle="#7CB3FF">
          打开宠物房（真动画版）
        </Text>
      </Link>
      <Button
        title="摸头一次"
        action={() => {
          doPet()
          Widget.reloadAll()
        }}
      />
      <Button
        title="投喂星尘一次"
        action={() => {
          doFeed()
          Widget.reloadAll()
        }}
      />
      <Button
        title="逗玩一次"
        action={() => {
          doPlay()
          Widget.reloadAll()
        }}
      />
      <Button
        title="重置宠物数值"
        action={() => {
          resetPet()
          Widget.reloadAll()
        }}
      />
      <Spacer />
      <HStack>
        <Text font={11} foregroundStyle="#6E7688">
          {`添加方式：长按桌面 → 添加小组件 → 选 Scripting → 选本脚本（推荐中号）。版本 ${WIDGET_VERSION}。`}
        </Text>
      </HStack>
    </VStack>
  )
}

async function main() {
  try {
    await ensureAssets()
  } catch {}
  await Navigation.present({ element: <App /> })
  Script.exit()
}

main()
