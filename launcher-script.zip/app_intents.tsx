// 空间启动器 · 组件内翻页意图（点按钮时执行，不打开 App）
import { AppIntentManager, AppIntentProtocol, Widget } from "scripting"
import {
  cachedCount,
  getEdit,
  getPage,
  getPages,
  hideSpace,
  markManual,
  moveSpace,
  setEdit,
  setPage,
  unhideAll,
} from "./model"

function totalPages(): number {
  const recorded = getPages()
  if (recorded > 0) return recorded
  return Math.max(1, Math.ceil(cachedCount() / 8))
}

export const NextPageIntent = AppIntentManager.register({
  name: "LauncherNextPage",
  protocol: AppIntentProtocol.AppIntent,
  perform: async () => {
    const pages = totalPages()
    setPage((getPage() + 1) % pages)
    markManual()
    Widget.reloadAll()
  },
})

export const PrevPageIntent = AppIntentManager.register({
  name: "LauncherPrevPage",
  protocol: AppIntentProtocol.AppIntent,
  perform: async () => {
    const pages = totalPages()
    setPage((getPage() - 1 + pages) % pages)
    markManual()
    Widget.reloadAll()
  },
})

// ---- 编辑态意图：进/出编辑、挪位、隐藏、恢复全部（iOS 小组件无长按与拖动手势，用按钮等效） ----

export const ToggleEditIntent = AppIntentManager.register({
  name: "LauncherToggleEdit",
  protocol: AppIntentProtocol.AppIntent,
  perform: async () => {
    setEdit(!getEdit())
    markManual()
    Widget.reloadAll()
  },
})

export const MoveSpaceIntent = AppIntentManager.register({
  name: "LauncherMoveSpace",
  protocol: AppIntentProtocol.AppIntent,
  perform: async ({ slug, dir }: { slug: string; dir: number }) => {
    moveSpace(slug, dir)
    markManual()
    Widget.reloadAll()
  },
})

export const HideSpaceIntent = AppIntentManager.register({
  name: "LauncherHideSpace",
  protocol: AppIntentProtocol.AppIntent,
  perform: async ({ slug }: { slug: string }) => {
    hideSpace(slug)
    markManual()
    Widget.reloadAll()
  },
})

export const UnhideAllIntent = AppIntentManager.register({
  name: "LauncherUnhideAll",
  protocol: AppIntentProtocol.AppIntent,
  perform: async () => {
    unhideAll()
    markManual()
    Widget.reloadAll()
  },
})
