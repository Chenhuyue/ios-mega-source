// 空间启动器 · 桌面小组件（Scripting）
// 卡片式 + 点按翻页（AppIntent）+ 自动轮播：系统每次刷新组件时自动翻到下一页；
// 手动点过翻页钮后的 90 秒内不自动翻，避免跟你抢。
import {
  Button,
  Capsule,
  Circle,
  HStack,
  Image,
  Link,
  RoundedRectangle,
  Spacer,
  Text,
  VStack,
  Widget,
  ZStack,
} from "scripting"
import {
  HideSpaceIntent,
  MoveSpaceIntent,
  NextPageIntent,
  PrevPageIntent,
  ToggleEditIntent,
  UnhideAllIntent,
} from "./app_intents"
import {
  BadgeMap,
  SpaceItem,
  getEdit,
  getHidden,
  getPage,
  iconURL,
  isNew,
  lastManualAt,
  loadBadges,
  loadSpaces,
  setPage,
  setPages,
  spaceURL,
} from "./model"

const BG = "#101218"
const CARD = "rgba(255,255,255,0.055)"
const SUB = "#9AA3B2"
const FAINT = "#6E7688"
const REFRESH_MINUTES = 30
const MANUAL_HOLD_MS = 90 * 1000

function perPageForFamily(): number {
  switch (Widget.family) {
    case "systemLarge":
      return 8
    case "systemMedium":
      return 4
    case "systemSmall":
      return 4
    default:
      return 8
  }
}

function MeiqiuMark() {
  return (
    <ZStack frame={{ width: 26, height: 26 }}>
      <Circle fill="#05060A" />
      <HStack spacing={3}>
        <Capsule fill="#F4F6FF" frame={{ width: 4, height: 11 }} />
        <Capsule fill="#F4F6FF" frame={{ width: 4, height: 11 }} />
      </HStack>
    </ZStack>
  )
}

function Header(total: number, edit: boolean) {
  return (
    <HStack spacing={8}>
      <MeiqiuMark />
      <VStack alignment="leading" spacing={1}>
        <Text font={15} fontWeight="bold" foregroundStyle="#F5F7FF">
          空间启动器
        </Text>
        <Text font={9} foregroundStyle={SUB}>
          {edit ? "编辑中 · 点箭头挪位，✕ 隐藏" : "常用排前面 · 自动轮播翻页"}
        </Text>
      </VStack>
      <Spacer />
      {edit ? null : (
        <Button intent={ToggleEditIntent(undefined)} buttonStyle="plain">
          <ZStack frame={{ width: 40, height: 21 }}>
            <RoundedRectangle cornerRadius={999} fill="rgba(255,255,255,0.10)" />
            <Text font={10} foregroundStyle="#C9D2E8">
              编辑
            </Text>
          </ZStack>
        </Button>
      )}
      <ZStack frame={{ width: 76, height: 21 }}>
        <RoundedRectangle cornerRadius={999} fill="rgba(255,255,255,0.10)" />
        <Text font={10} foregroundStyle="#C9D2E8">
          {`${total} 个空间`}
        </Text>
      </ZStack>
    </HStack>
  )
}

function NewTag() {
  return (
    <ZStack frame={{ width: 26, height: 12 }}>
      <RoundedRectangle cornerRadius={999} fill="#E5484D" />
      <Text font={7} fontWeight="bold" foregroundStyle="#FFFFFF">
        NEW
      </Text>
    </ZStack>
  )
}

function Card(item: SpaceItem, showSlug: boolean, height: number, badges: BadgeMap) {
  const badge = badges[item.slug]
  const slugText = item.slug.length > 24 ? item.slug.slice(0, 24) + "…" : item.slug
  return (
    <Link url={spaceURL(item.slug)}>
      <ZStack
        frame={{ maxWidth: "infinity", height: height }}
        background={<RoundedRectangle cornerRadius={12} fill={CARD} />}
      >
        <HStack spacing={8} padding={{ horizontal: 9 }} frame={{ maxWidth: "infinity" }}>
          <ZStack frame={{ width: height - 18, height: height - 18 }}>
            <RoundedRectangle cornerRadius={8} fill={item.color} />
            <Image
              imageUrl={iconURL(item.slug)}
              resizable={{ resizingMode: "stretch" }}
              frame={{ width: height - 18, height: height - 18 }}
              width={height - 18}
              height={height - 18}
              placeholder={<RoundedRectangle cornerRadius={8} fill={item.color} />}
            />
          </ZStack>
          <VStack alignment="leading" spacing={1}>
            <HStack spacing={4}>
              <Text font={12} fontWeight="semibold" foregroundStyle="#F2F5FF">
                {item.name}
              </Text>
              {isNew(item) ? <NewTag /> : null}
            </HStack>
            {showSlug || badge ? (
              <HStack spacing={3}>
                {showSlug ? (
                  <Text font={8} foregroundStyle={FAINT}>
                    {slugText}
                  </Text>
                ) : null}
                {badge ? (
                  <Text font={8} fontWeight="semibold" foregroundStyle={badge.hot ? "#FF8A8A" : "#D8C58F"}>
                    {showSlug ? `· ${badge.text}` : badge.text}
                  </Text>
                ) : null}
              </HStack>
            ) : null}
          </VStack>
          <Spacer />
        </HStack>
      </ZStack>
    </Link>
  )
}

function ChipButton(intent: any, label: string, width: number, danger?: boolean) {
  return (
    <Button intent={intent} buttonStyle="plain">
      <ZStack frame={{ width: width, height: 26 }}>
        <RoundedRectangle
          cornerRadius={999}
          fill={danger ? "rgba(229,72,77,0.25)" : "rgba(255,255,255,0.12)"}
        />
        <Text font={11} fontWeight="semibold" foregroundStyle={danger ? "#FF9C9C" : "#E8EDFF"}>
          {label}
        </Text>
      </ZStack>
    </Button>
  )
}

/** 编辑态卡片：不跳转，右侧 ‹ › 挪位、✕ 本机隐藏。 */
function EditCard(item: SpaceItem, height: number) {
  return (
    <ZStack
      frame={{ maxWidth: "infinity", height: height }}
      background={<RoundedRectangle cornerRadius={12} fill={CARD} />}
    >
      <HStack spacing={6} padding={{ horizontal: 9 }} frame={{ maxWidth: "infinity" }}>
        <ZStack frame={{ width: height - 18, height: height - 18 }}>
          <RoundedRectangle cornerRadius={8} fill={item.color} />
          <Image
            imageUrl={iconURL(item.slug)}
            resizable={{ resizingMode: "stretch" }}
            frame={{ width: height - 18, height: height - 18 }}
            width={height - 18}
            height={height - 18}
            placeholder={<RoundedRectangle cornerRadius={8} fill={item.color} />}
          />
        </ZStack>
        <Text font={12} fontWeight="semibold" foregroundStyle="#F2F5FF">
          {item.name}
        </Text>
        <Spacer />
        {ChipButton(MoveSpaceIntent({ slug: item.slug, dir: -1 }), "‹", 24)}
        {ChipButton(MoveSpaceIntent({ slug: item.slug, dir: 1 }), "›", 24)}
        {ChipButton(HideSpaceIntent({ slug: item.slug }), "✕", 24, true)}
      </HStack>
    </ZStack>
  )
}

function EmptyCard(height: number) {
  return (
    <ZStack
      frame={{ maxWidth: "infinity", height: height }}
      background={<RoundedRectangle cornerRadius={12} fill="rgba(255,255,255,0.0)" />}
    >
      <Text font={1} foregroundStyle="rgba(255,255,255,0)">
        {" "}
      </Text>
    </ZStack>
  )
}

function Pager(page: number, pages: number, edit: boolean, hiddenCount: number) {
  const dots = Array.from({ length: pages }, (_, i) => (i === page ? "●" : "○")).join(" ")
  if (edit) {
    return (
      <HStack spacing={8}>
        <Button intent={ToggleEditIntent(undefined)} buttonStyle="plain">
          <ZStack frame={{ width: 52, height: 24 }}>
            <RoundedRectangle cornerRadius={999} fill="#3B82F6" />
            <Text font={11} fontWeight="bold" foregroundStyle="#FFFFFF">
              完成
            </Text>
          </ZStack>
        </Button>
        {hiddenCount > 0 ? (
          <Button intent={UnhideAllIntent(undefined)} buttonStyle="plain">
            <ZStack frame={{ width: 118, height: 24 }}>
              <RoundedRectangle cornerRadius={999} fill="rgba(255,255,255,0.10)" />
              <Text font={10} foregroundStyle="#E8EDFF">
                {`已隐藏 ${hiddenCount} 张 · 恢复`}
              </Text>
            </ZStack>
          </Button>
        ) : (
          <Text font={10} foregroundStyle={SUB}>
            {`第 ${page + 1} / ${pages} 页`}
          </Text>
        )}
        <Spacer />
        <Button intent={PrevPageIntent(undefined)} buttonStyle="plain">
          <ZStack frame={{ width: 62, height: 24 }}>
            <RoundedRectangle cornerRadius={999} fill="rgba(255,255,255,0.10)" />
            <Text font={11} foregroundStyle="#E8EDFF">
              ‹ 上页
            </Text>
          </ZStack>
        </Button>
        <Button intent={NextPageIntent(undefined)} buttonStyle="plain">
          <ZStack frame={{ width: 62, height: 24 }}>
            <RoundedRectangle cornerRadius={999} fill="rgba(255,255,255,0.10)" />
            <Text font={11} foregroundStyle="#E8EDFF">
              下页 ›
            </Text>
          </ZStack>
        </Button>
      </HStack>
    )
  }
  return (
    <HStack spacing={8}>
      <Text font={10} foregroundStyle={SUB}>
        {`第 ${page + 1} / ${pages} 页 · v1.3.0`}
      </Text>
      <Spacer />
      <Text font={9} foregroundStyle={SUB}>
        {dots}
      </Text>
      <Spacer />
      <Button intent={PrevPageIntent(undefined)} buttonStyle="plain">
        <ZStack frame={{ width: 62, height: 24 }}>
          <RoundedRectangle cornerRadius={999} fill="rgba(255,255,255,0.10)" />
          <Text font={11} foregroundStyle="#E8EDFF">
            ‹ 上页
          </Text>
        </ZStack>
      </Button>
      <Button intent={NextPageIntent(undefined)} buttonStyle="plain">
        <ZStack frame={{ width: 62, height: 24 }}>
          <RoundedRectangle cornerRadius={999} fill="rgba(255,255,255,0.10)" />
          <Text font={11} foregroundStyle="#E8EDFF">
            下页 ›
          </Text>
        </ZStack>
      </Button>
    </HStack>
  )
}

function LargeView(
  spaces: SpaceItem[],
  page: number,
  pages: number,
  badges: BadgeMap,
  edit: boolean,
  hiddenCount: number
) {
  const per = 8
  const items = spaces.slice(page * per, page * per + per)
  const rows: SpaceItem[][] = []
  for (let i = 0; i < items.length; i += 2) rows.push(items.slice(i, i + 2))
  const cell = (it: SpaceItem) => (edit ? EditCard(it, 54) : Card(it, true, 54, badges))
  return (
    <VStack alignment="leading" spacing={8} padding={13} background={BG}>
      {Header(spaces.length, edit)}
      {rows.map((row) => (
        <HStack spacing={8}>
          {cell(row[0])}
          {row[1] ? cell(row[1]) : EmptyCard(54)}
        </HStack>
      ))}
      <Spacer />
      {Pager(page, pages, edit, hiddenCount)}
    </VStack>
  )
}

function MediumView(
  spaces: SpaceItem[],
  page: number,
  pages: number,
  badges: BadgeMap,
  edit: boolean,
  hiddenCount: number
) {
  const per = 4
  const items = spaces.slice(page * per, page * per + per)
  const rows: SpaceItem[][] = []
  for (let i = 0; i < items.length; i += 2) rows.push(items.slice(i, i + 2))
  const cell = (it: SpaceItem) => (edit ? EditCard(it, 46) : Card(it, false, 46, badges))
  return (
    <VStack alignment="leading" spacing={8} padding={12} background={BG}>
      {Header(spaces.length, edit)}
      {rows.map((row) => (
        <HStack spacing={8}>
          {cell(row[0])}
          {row[1] ? cell(row[1]) : EmptyCard(46)}
        </HStack>
      ))}
      <Spacer />
      {Pager(page, pages, edit, hiddenCount)}
    </VStack>
  )
}

function SmallView(spaces: SpaceItem[], page: number, pages: number, edit: boolean, hiddenCount: number) {
  const per = 4
  const items = spaces.slice(page * per, page * per + per)
  const rowIcon = (item: SpaceItem) => (
    <ZStack frame={{ width: 24, height: 24 }}>
      <RoundedRectangle cornerRadius={6} fill={item.color} />
      <Image
        imageUrl={iconURL(item.slug)}
        resizable={{ resizingMode: "stretch" }}
        frame={{ width: 24, height: 24 }}
        width={24}
        height={24}
        placeholder={<RoundedRectangle cornerRadius={6} fill={item.color} />}
      />
    </ZStack>
  )
  return (
    <VStack alignment="leading" spacing={7} padding={11} background={BG}>
      <HStack spacing={6}>
        <MeiqiuMark />
        <Text font={12} fontWeight="bold" foregroundStyle="#F5F7FF">
          空间启动器
        </Text>
        <Spacer />
        <Button intent={ToggleEditIntent(undefined)} buttonStyle="plain">
          <Text font={10} fontWeight="semibold" foregroundStyle={edit ? "#6FB1FF" : SUB}>
            {edit ? "完成" : "编辑"}
          </Text>
        </Button>
      </HStack>
      {items.map((item) =>
        edit ? (
          <HStack spacing={5}>
            {rowIcon(item)}
            <Text font={11} foregroundStyle="#EDF1FF">
              {item.name}
            </Text>
            <Spacer />
            {ChipButton(MoveSpaceIntent({ slug: item.slug, dir: -1 }), "‹", 20)}
            {ChipButton(MoveSpaceIntent({ slug: item.slug, dir: 1 }), "›", 20)}
            {ChipButton(HideSpaceIntent({ slug: item.slug }), "✕", 20, true)}
          </HStack>
        ) : (
          <Link url={spaceURL(item.slug)}>
            <HStack spacing={7}>
              {rowIcon(item)}
              <Text font={11} foregroundStyle="#EDF1FF">
                {item.name}
              </Text>
              {isNew(item) ? <Circle fill="#E5484D" frame={{ width: 5, height: 5 }} /> : null}
              <Spacer />
            </HStack>
          </Link>
        )
      )}
      <Spacer />
      {edit && hiddenCount > 0 ? (
        <Button intent={UnhideAllIntent(undefined)} buttonStyle="plain">
          <Text font={9} foregroundStyle="#6FB1FF">
            {`已隐藏 ${hiddenCount} 张 · 点此恢复全部`}
          </Text>
        </Button>
      ) : (
        <Text font={9} foregroundStyle={SUB}>
          {`第 ${page + 1} / ${pages} 页 · 自动轮播`}
        </Text>
      )}
    </VStack>
  )
}

async function main() {
  const reloadPolicy = {
    policy: "after",
    date: new Date(Date.now() + REFRESH_MINUTES * 60 * 1000),
  } as const

  let spaces: SpaceItem[] = []
  try {
    spaces = await loadSpaces()
  } catch {
    spaces = []
  }
  let badges: BadgeMap = {}
  try {
    badges = await loadBadges()
  } catch {
    badges = {}
  }

  const edit = getEdit()
  const hiddenCount = getHidden().length

  const per = perPageForFamily()
  const pages = Math.max(1, Math.ceil(spaces.length / per))
  setPages(pages)

  // 页码决定：手动翻页后 90 秒内听用户的；编辑中不轮播；其余时候每次刷新自动轮播一页。
  let page = getPage() % pages
  if (!edit && Date.now() - lastManualAt() > MANUAL_HOLD_MS) {
    page = (page + 1) % pages
    setPage(page)
  }

  try {
    switch (Widget.family) {
      case "systemMedium":
        Widget.present(MediumView(spaces, page, pages, badges, edit, hiddenCount), { reloadPolicy })
        break
      case "systemSmall":
        Widget.present(SmallView(spaces, page, pages, edit, hiddenCount), { reloadPolicy })
        break
      case "systemLarge":
      case "systemExtraLarge":
        Widget.present(LargeView(spaces, page, pages, badges, edit, hiddenCount), { reloadPolicy })
        break
      default:
        Widget.present(
          <VStack padding={12} background={BG}>
            <Text font={12} foregroundStyle="#F5F7FF">
              {`空间启动器 · ${spaces.length} 个空间`}
            </Text>
          </VStack>,
          { reloadPolicy }
        )
    }
  } catch {
    Widget.present(
      <VStack padding={12} background={BG}>
        <Text font={12} foregroundStyle="#F5F7FF">
          空间启动器
        </Text>
      </VStack>,
      { reloadPolicy }
    )
  }
}

main()
