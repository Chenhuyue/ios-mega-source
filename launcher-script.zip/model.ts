// 空间启动器 · 数据层（widget.tsx / app_intents.tsx / index.tsx 共用）
// 名单与图标托管在 GitHub 仓库 Chenhuyue/ios-mega-source，脚本自动拉取并缓存。
// 拉不到时依次用：上次缓存 → 内置 21 条，组件永远能渲染。

export type SpaceItem = {
  name: string
  slug: string
  color: string
  fav?: boolean
  added?: string
  hits?: number
}

export type BadgeInfo = { text: string; hot?: boolean }
export type BadgeMap = Record<string, BadgeInfo>

export const LIST_URLS = [
  "https://cdn.jsdelivr.net/gh/Chenhuyue/ios-mega-source@main/launcher.json",
  "https://fastly.jsdelivr.net/gh/Chenhuyue/ios-mega-source@main/launcher.json",
  "https://raw.githubusercontent.com/Chenhuyue/ios-mega-source/main/launcher.json",
]

export const BADGE_URLS = [
  "https://cdn.jsdelivr.net/gh/Chenhuyue/ios-mega-source@main/badges.json",
  "https://fastly.jsdelivr.net/gh/Chenhuyue/ios-mega-source@main/badges.json",
  "https://raw.githubusercontent.com/Chenhuyue/ios-mega-source/main/badges.json",
]

export const ICON_BASE =
  "https://cdn.jsdelivr.net/gh/Chenhuyue/ios-mega-source@main/icons-png"

export const LAUNCHER_URL = "hatch://space/kong-jian-qi-dong-qi"

export function spaceURL(slug: string): string {
  return `hatch://space/${slug}`
}

export function iconURL(slug: string): string {
  return `${ICON_BASE}/icon-${slug}.png`
}

const SPACES_KEY = "launcher.spaces.v1"
const PAGE_KEY = "launcher.page.v1"
const MANUAL_AT_KEY = "launcher.manualAt.v1"
const COUNT_KEY = "launcher.count.v1"
const UPDATED_KEY = "launcher.updated.v1"
const BADGES_KEY = "launcher.badges.v1"
const PAGES_KEY = "launcher.pages.v1"
const ORDER_KEY = "launcher.order.v1"
const HIDDEN_KEY = "launcher.hidden.v1"
const EDIT_KEY = "launcher.edit.v1"

export const FALLBACK: SpaceItem[] = [
  { name: "VPS 总台", slug: "vps-zi-chan-guan-li", color: "#5B8DEF", fav: true },
  { name: "API 与 AI 管理", slug: "api-yu-ai-guan-li", color: "#7C5CFC", fav: true },
  { name: "薅羊毛", slug: "dian-zi-chan-pin-hao-yang-mao", color: "#FF9F43", fav: true },
  { name: "AV 个性化推荐", slug: "av-ge-xing-hua-tui-jian", color: "#FF5C7A", fav: true },
  { name: "Muse 宠物房", slug: "muse-chong-wu-fang", color: "#6366F1", added: "2026-11-18" },
  { name: "星核真3D小样", slug: "xing-he-zhen-3dxiao-yang", color: "#818CF8", added: "2026-11-18" },
  { name: "3D 办公室", slug: "3d-ban-gong-shi", color: "#38B2AC" },
  { name: "搁置与未完成总览", slug: "ge-zhi-yu-wei-wan-cheng-zong-lan", color: "#9AA3B2" },
  { name: "Telegram 管理看板", slug: "telegram-guan-li-kan-ban", color: "#37AEE2" },
  { name: "自慰记录看板", slug: "zi-wei-ji-lu-kan-ban", color: "#A55EEA" },
  { name: "捡垃圾情报站", slug: "jian-la-ji-qing-bao-zhan", color: "#26C281" },
  { name: "闲鱼蹲货看板", slug: "xian-yu-dun-huo-kan-ban", color: "#FF7B54" },
  { name: "VPS 监控看板", slug: "vps-jian-kong-kan-ban", color: "#4BCFFA" },
  { name: "网名雷达", slug: "sherlock-kan-ban", color: "#FD79A8" },
  { name: "HGhub Web 看板", slug: "hghub-web-kan-ban", color: "#F6B93B" },
  { name: "图片提示词库", slug: "tu-pian-ti-shi-ci-ku", color: "#6C5CE7" },
  { name: "无限画布", slug: "wu-xian-hua-bu", color: "#00CEC9" },
  { name: "云电脑出图台", slug: "yun-dian-nao-chu-tu-tai", color: "#74B9FF" },
  { name: "iOS 签名工具箱", slug: "ios-qian-ming-gong-ju-xiang", color: "#E17055" },
  { name: "Recent 案例拆解看板", slug: "recent-an-li-chai-jie-kan-ban", color: "#55E6C1" },
  { name: "Skills 管理器", slug: "skills-guan-li-qi", color: "#84CC16", added: "2026-11-18" },
  { name: "找源技术调研", slug: "zhao-yuan-ji-shu-diao-yan", color: "#B8C2CC" },
  { name: "Apple TV 调研", slug: "apple-tv", color: "#7A8699" },
  { name: "云 GPU 调研", slug: "gpu", color: "#FDCB6E" },
  { name: "多AI群聊空间", slug: "duo-aiqun-liao-kong-jian", color: "#6366F1", added: "2026-11-19" },
  { name: "Grok Bot 还原", slug: "grok-bot-huan-yuan", color: "#84CC16", added: "2026-11-19" },
  { name: "Clash 看板", slug: "clash-kan-ban", color: "#818CF8", added: "2026-11-20" },
  { name: "四川话发音与谐音换调研究", slug: "si-chuan-hua-fa-yin-yu-xie-yin-huan-diao-yan-jiu", color: "#F472B6", added: "2026-11-20" },
  { name: "预告标记对照样张", slug: "yu-gao-biao-ji-dui-zhao-yang-zhang", color: "#34D399", added: "2026-11-20" },
  { name: "首页改版样张", slug: "shou-ye-gai-ban-yang-zhang", color: "#FBBF24", added: "2026-11-21" },
  { name: "预告屏蔽根因调研", slug: "yu-gao-ping-bi-gen-yin-diao-yan", color: "#6366F1", added: "2026-11-22" },
  { name: "家底图 · 动态看板", slug: "jia-di-tu-dong-tai-kan-ban", color: "#84CC16", added: "2026-11-28" },
  { name: "Muse 办公室", slug: "man-you-ban-gong-shi", color: "#818CF8", added: "2026-11-28" },
]

function byHitsDesc(list: SpaceItem[]): SpaceItem[] {
  return list
    .map((x, i) => ({ x, i }))
    .sort((a, b) => (b.x.hits ?? 0) - (a.x.hits ?? 0) || a.i - b.i)
    .map((w) => w.x)
}

/** 常用置顶；两组内部按使用热度（hits，面板点击统计回流）降序，热度相同保持名单顺序。 */
function sortedFavFirst(list: SpaceItem[]): SpaceItem[] {
  const favs = byHitsDesc(list.filter((x) => x.fav))
  const rest = byHitsDesc(list.filter((x) => !x.fav))
  return [...favs, ...rest]
}

// ---- 编辑态：手动顺序＋本机隐藏（只存本机 Storage，不回传、不动远程名单） ----

export function getOrder(): string[] {
  const o = Storage.get<string[]>(ORDER_KEY)
  return Array.isArray(o) ? o.filter((s) => typeof s === "string") : []
}

export function getHidden(): string[] {
  const h = Storage.get<string[]>(HIDDEN_KEY)
  return Array.isArray(h) ? h.filter((s) => typeof s === "string") : []
}

export function getEdit(): boolean {
  return Storage.get<boolean>(EDIT_KEY) === true
}

export function setEdit(on: boolean) {
  Storage.set(EDIT_KEY, on)
}

/** 显示管线：手动顺序优先（表里没有的新卡按原序补到末尾），再滤掉本机隐藏。 */
export function applyLocalPrefs(list: SpaceItem[]): SpaceItem[] {
  const order = getOrder()
  let out = list
  if (order.length > 0) {
    const pos = new Map(order.map((s, i) => [s, i] as const))
    out = list
      .map((x, i) => ({ x, i }))
      .sort((a, b) => {
        const pa = pos.has(a.x.slug) ? (pos.get(a.x.slug) as number) : order.length + a.i
        const pb = pos.has(b.x.slug) ? (pos.get(b.x.slug) as number) : order.length + b.i
        return pa - pb || a.i - b.i
      })
      .map((w) => w.x)
  }
  const hidden = getHidden()
  if (hidden.length > 0) {
    const hs = new Set(hidden)
    out = out.filter((x) => !hs.has(x.slug))
  }
  return out
}

/** 同步读缓存名单并走完整显示管线（意图里算顺序/移动/计数用，不发网络请求）。 */
export function visibleCachedSpaces(): SpaceItem[] {
  const cached = Storage.get<SpaceItem[]>(SPACES_KEY)
  const base = cached && cached.length > 0 ? cached : FALLBACK
  return applyLocalPrefs(sortedFavFirst(base))
}

/** 把卡片在当前可见序列里前/后挪一位，整表存回（dir<0 向前，>0 向后）。 */
export function moveSpace(slug: string, dir: number) {
  const seq = visibleCachedSpaces()
  const i = seq.findIndex((x) => x.slug === slug)
  if (i < 0) return
  const j = i + (dir < 0 ? -1 : 1)
  if (j < 0 || j >= seq.length) return
  const slugs = seq.map((x) => x.slug)
  const tmp = slugs[i]
  slugs[i] = slugs[j]
  slugs[j] = tmp
  Storage.set(ORDER_KEY, slugs)
}

/** 本机隐藏一张卡（可恢复：编辑态里「恢复全部」）。 */
export function hideSpace(slug: string) {
  const h = getHidden()
  if (!h.includes(slug)) Storage.set(HIDDEN_KEY, [...h, slug])
}

export function unhideAll() {
  Storage.set(HIDDEN_KEY, [])
}

/** 进名单 7 天内算新（面板与小组件的 NEW 标共用口径）。 */
export function isNew(item: SpaceItem): boolean {
  if (!item.added) return false
  const t = Date.parse(item.added + "T00:00:00")
  if (Number.isNaN(t)) return false
  const days = (Date.now() - t) / 86400000
  return days >= 0 && days <= 7
}

function withTimeout<T>(work: Promise<T>, ms: number): Promise<T | null> {
  return Promise.race([
    work.catch(() => null),
    new Promise<null>((resolve) => setTimeout(() => resolve(null), ms)),
  ]) as Promise<T | null>
}

async function fetchList(): Promise<{ spaces: SpaceItem[]; updated?: string } | null> {
  for (const url of LIST_URLS) {
    const data = await withTimeout(
      (async () => {
        const res = await fetch(url)
        if (!res.ok) return null
        const json: any = await res.json()
        const arr = Array.isArray(json) ? json : json.spaces
        if (!Array.isArray(arr) || arr.length === 0) return null
        const spaces = arr
          .filter((x: any) => x && x.name && x.slug)
          .map((x: any) => ({
            name: String(x.name),
            slug: String(x.slug),
            color: String(x.color ?? "#8A93A6"),
            fav: !!x.fav,
            added: x.added ? String(x.added) : undefined,
            hits: typeof x.hits === "number" ? x.hits : undefined,
          })) as SpaceItem[]
        return { spaces, updated: json && json.updated ? String(json.updated) : undefined }
      })(),
      5000
    )
    if (data && data.spaces.length > 0) return data
  }
  return null
}

async function fetchBadges(): Promise<BadgeMap | null> {
  for (const url of BADGE_URLS) {
    const data = await withTimeout(
      (async () => {
        const res = await fetch(url)
        if (!res.ok) return null
        const json: any = await res.json()
        const map = json && json.badges
        if (!map || typeof map !== "object") return null
        const out: BadgeMap = {}
        for (const k of Object.keys(map)) {
          const v = map[k]
          if (v && v.text) out[k] = { text: String(v.text), hot: !!v.hot }
        }
        return out
      })(),
      4000
    )
    if (data) return data
  }
  return null
}

/** 拉状态角标（成功后写缓存）；失败回退缓存，再失败为空。 */
export async function loadBadges(): Promise<BadgeMap> {
  const fresh = await fetchBadges()
  if (fresh) {
    Storage.set(BADGES_KEY, fresh)
    return fresh
  }
  const cached = Storage.get<BadgeMap>(BADGES_KEY)
  return cached && typeof cached === "object" ? cached : {}
}

/** 拉最新名单（成功后写缓存）；失败回退缓存，再失败回退内置名单。 */
export async function loadSpaces(): Promise<SpaceItem[]> {
  const got = await fetchList()
  // 日期防回滚：拉到的名单若比缓存还旧（某 CDN 节点缓存没刷新），不用它，继续走缓存。
  const cachedUpdated = Storage.get<string>(UPDATED_KEY)
  const fresh =
    got && (!got.updated || !cachedUpdated || got.updated >= cachedUpdated) ? got.spaces : null
  if (fresh) {
    Storage.set(SPACES_KEY, fresh)
    Storage.set(COUNT_KEY, fresh.length)
    if (got && got.updated) Storage.set(UPDATED_KEY, got.updated)
    return applyLocalPrefs(sortedFavFirst(fresh))
  }
  const cached = Storage.get<SpaceItem[]>(SPACES_KEY)
  if (cached && cached.length > 0) return applyLocalPrefs(sortedFavFirst(cached))
  Storage.set(COUNT_KEY, FALLBACK.length)
  return applyLocalPrefs(sortedFavFirst(FALLBACK))
}

/** 同步读可见卡片数（已扣掉本机隐藏；意图里算总页数用）。 */
export function cachedCount(): number {
  return visibleCachedSpaces().length
}

export function getPage(): number {
  const p = Storage.get<number>(PAGE_KEY)
  return typeof p === "number" && p >= 0 ? Math.floor(p) : 0
}

export function setPage(p: number) {
  Storage.set(PAGE_KEY, p)
}

export function markManual() {
  Storage.set(MANUAL_AT_KEY, Date.now())
}

export function lastManualAt(): number {
  const t = Storage.get<number>(MANUAL_AT_KEY)
  return typeof t === "number" ? t : 0
}

export function resetPage() {
  Storage.set(PAGE_KEY, 0)
  Storage.set(MANUAL_AT_KEY, Date.now())
}

/** widget.tsx 每次渲染时记下当前尺寸下的总页数，意图翻页时按这个数回绕。 */
export function setPages(p: number) {
  Storage.set(PAGES_KEY, Math.max(1, p))
}

export function getPages(): number {
  const p = Storage.get<number>(PAGES_KEY)
  return typeof p === "number" && p > 0 ? Math.floor(p) : 0
}
